#! /bin/sh

kill -9 `ps -ef|grep java|grep -v grep|grep rocketmq-console|awk '{print $2}'`
