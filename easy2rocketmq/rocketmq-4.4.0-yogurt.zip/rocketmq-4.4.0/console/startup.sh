#! /bin/sh

nohup ${JAVA_HOME}/bin/java -Xms512M -Xmx512M -Xmn200M -jar ${ROCKET_MQ_HOME}/console/rocketmq-console.jar --spring.config.location=${ROCKET_MQ_HOME}/console/application.properties > ${ROCKET_MQ_HOME}/console/stdout.log &


